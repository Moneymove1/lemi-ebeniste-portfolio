import { useEffect, useRef, useState, useCallback, type ReactNode } from "react";
import { Link } from "wouter";

/*
 * ═══════════════════════════════════════════════════════════════
 * MAÎTRE ÉBÉNISTE — LUXURY PORTFOLIO
 * Design: Editorial luxury — DM Sans (geometric) + Cormorant Garamond (serif accents)
 * Every proportion calculated. Every spacing intentional.
 * ═══════════════════════════════════════════════════════════════
 */

// ─── Design Tokens ─────────────────────────────────────────────
const sans = "'DM Sans', system-ui, sans-serif";
const serif = "'Cormorant Garamond', 'Georgia', serif";

const C = {
  ivory: "#F5F3EE",
  white: "#FFFFFF",
  charcoal: "#1C1C1C",
  dark: "#2A2825",
  text: "#3D3A36",
  mid: "#7A756D",
  light: "#A8A29E",
  faint: "#C8C3BB",
  line: "#E5E1DA",
  lineLight: "#EDEBE6",
};

// ─── CDN Images ────────────────────────────────────────────────
const CDN = "https://files.manuscdn.com/user_upload_by_module/session_file/104907534/";
const IMG = {
  // Hero
  cuisineGrise: CDN + "IkvbNriYsSGaVDdA.png",

  // ── COMMERCIAL (#1–#6) ──
  p1: CDN + "AXJIyTfTDcDdTVsB.png",   // #1 red interior counter
  p2: CDN + "VTywzyQWiAJtgMMc.png",   // #2 KV arch glasses
  p3: CDN + "OfbsrRcEExFNGlsq.png",   // #3 close-up red shelves
  p4: CDN + "vHtMNCQSMMRkUEGQ.png",   // #4 marble wall logo
  p5: CDN + "zrlVVgccneNsfCgB.png",   // #5 arched shelving mirrors
  p6: CDN + "UMAYnIrxXfpQURtm.png",   // #6 red shelves close-up

  // ── RESIDENTIAL (#7–#24) ──
  p7:  CDN + "lzywczCabnHZhUOv.png",  // #7  biblio bûches (533×800 portrait)
  p8:  CDN + "hFPtjbvbOgbZNOYB.png",  // #8  chevet lampe (533×800 portrait)
  p9:  CDN + "NbAyRqXJZeemGjJp.png",  // #9  meuble TV livres (1360×907 landscape)
  p10: CDN + "ExazOqiYLADjCqcp.png",  // #10 armoire blanche (716×907 portrait)
  p11: CDN + "yfrqhbLcoiserpzB.png",  // #11 garde-robe miroir (898×595 landscape)
  p12: CDN + "etwqcQeUcRYzImde.png",  // #12 armoire luminaire (284×462 portrait)
  p13: CDN + "OqJCvXmrpSTQXmFg.png",  // #13 cuisine grise îlot (1200×800 landscape)
  p14: CDN + "AhFwCwZKrUepzUgd.png",  // #14 armoire bouleau skylight (1024×1536 portrait)
  p15: CDN + "mVACMyhViazwdMUr.png",  // #15 armoire bouleau angle (1024×1536 portrait)
  p16: CDN + "hZcSHpDvtWSJHiQb.png",  // #16 escalier étagères (1024×1536 portrait)
  p17: CDN + "EKGEskRRYEWoofkP.png",  // #17 mur TV noir (1024×1536 portrait)
  p18: CDN + "EvdSVWXirASpmVFJ.png",  // #18 meuble TV bois (1024×1536 portrait)
  p19: CDN + "kAAcYTSMKAJzvabW.png",  // #19 bureau iMac (1024×1536 portrait)
  p20: CDN + "VPUGEvQzDXkaoqYW.png",  // #20 armoire chêne (533×800 portrait)
  p21: CDN + "cNTsnRFZoPQcbHJz.png",  // #21 biblio TV livres (533×800 portrait)
  p22: CDN + "JUQFvTZzKRCwZBYQ.png",  // #22 crédence blanche (1536×1024 landscape)
  p23: CDN + "eKpTRYDGcfqeJykm.jpg",  // #23 miroir moulures (2048×1536 landscape)
  p24: CDN + "vxwhPtNmMtkVogUj.png",  // #24 entrée console (1805×1519 ~square)
};

/* ── Reveal on scroll with stagger ── */
function Reveal({ children, className = "", delay = 0, y = 30, style }: { children: ReactNode; className?: string; delay?: number; y?: number; style?: React.CSSProperties }) {
  const ref = useRef<HTMLDivElement>(null);
  const [vis, setVis] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([e]) => { if (e.isIntersecting) { setVis(true); obs.unobserve(el); } },
      { threshold: 0.08, rootMargin: "20px" }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);
  return (
    <div
      ref={ref}
      className={className}
      style={{
        opacity: vis ? 1 : 0,
        transform: vis ? "translateY(0)" : `translateY(${y}px)`,
        transition: `opacity 0.9s cubic-bezier(0.22, 1, 0.36, 1) ${delay}ms, transform 0.9s cubic-bezier(0.22, 1, 0.36, 1) ${delay}ms`,
        ...style,
      }}
    >
      {children}
    </div>
  );
}

/* ── Image with zoom on hover + lazy load ── */
function GalleryImage({ src, alt, aspect = "4/3", mobileAspect, className = "", objectPosition = "center" }: { src: string; alt: string; aspect?: string; mobileAspect?: string; className?: string; objectPosition?: string }) {
  const [loaded, setLoaded] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  useEffect(() => {
    const check = () => setIsMobile(window.innerWidth < 768);
    check();
    window.addEventListener("resize", check);
    return () => window.removeEventListener("resize", check);
  }, []);
  const currentAspect = (isMobile && mobileAspect) ? mobileAspect : aspect;
  return (
    <div
      className={`overflow-hidden group ${className}`}
      style={{ aspectRatio: currentAspect, backgroundColor: C.lineLight }}
    >
      <img
        src={src}
        alt={alt}
        loading="lazy"
        onLoad={() => setLoaded(true)}
        className="w-full h-full object-cover transition-all duration-[1.2s] ease-out group-hover:scale-[1.04]"
        style={{ opacity: loaded ? 1 : 0, objectPosition }}
      />
    </div>
  );
}

/* ── Lightbox ── */
function Lightbox({ images, index, onClose, onNav }: { images: string[]; index: number; onClose: () => void; onNav: (i: number) => void }) {
  useEffect(() => {
    const fn = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowRight") onNav(Math.min(index + 1, images.length - 1));
      if (e.key === "ArrowLeft") onNav(Math.max(index - 1, 0));
    };
    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", fn);
    return () => { document.body.style.overflow = ""; window.removeEventListener("keydown", fn); };
  }, [index, images.length, onClose, onNav]);

  return (
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center"
      style={{ backgroundColor: "rgba(28,28,28,0.92)", backdropFilter: "blur(20px)" }}
      onClick={onClose}
    >
      <button
        onClick={onClose}
        className="absolute top-4 right-4 md:top-6 md:right-6 z-10 w-12 h-12 flex items-center justify-center"
        style={{ color: "#fff" }}
      >
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
          <path d="M18 6L6 18M6 6l12 12" />
        </svg>
      </button>

      {index > 0 && (
        <button
          onClick={(e) => { e.stopPropagation(); onNav(index - 1); }}
          className="absolute left-4 md:left-8 top-1/2 -translate-y-1/2 w-12 h-12 flex items-center justify-center"
          style={{ color: "#fff" }}
        >
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
            <path d="M15 19l-7-7 7-7" />
          </svg>
        </button>
      )}
      {index < images.length - 1 && (
        <button
          onClick={(e) => { e.stopPropagation(); onNav(index + 1); }}
          className="absolute right-4 md:right-8 top-1/2 -translate-y-1/2 w-12 h-12 flex items-center justify-center"
          style={{ color: "#fff" }}
        >
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
            <path d="M9 5l7 7-7 7" />
          </svg>
        </button>
      )}

      <img
        src={images[index]}
        alt=""
        onClick={(e) => e.stopPropagation()}
        className="max-w-[95vw] md:max-w-[90vw] max-h-[80vh] md:max-h-[85vh] object-contain"
        style={{ animation: "fadeIn 0.3s ease" }}
      />

      <div className="absolute bottom-6 left-1/2 -translate-x-1/2" style={{ fontFamily: sans, fontSize: "0.8rem", fontWeight: 400, color: "rgba(255,255,255,0.5)", letterSpacing: "0.1em" }}>
        {index + 1} / {images.length}
      </div>

      <style>{`@keyframes fadeIn { from { opacity: 0; transform: scale(0.97); } to { opacity: 1; transform: scale(1); } }`}</style>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════
   NAVBAR — Refined, minimal, perfectly spaced
   ══════════════════════════════════════════════════════════════ */
function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", fn, { passive: true });
    return () => window.removeEventListener("scroll", fn);
  }, []);

  const links = [
    { label: "Projets", href: "#projets" },
    { label: "Commercial", href: "#commercial" },
    { label: "Résidentiel", href: "#residentiel" },
    { label: "Contact", href: "#contact" },
  ];

  return (
    <nav
      className="fixed top-0 left-0 right-0 z-50 transition-all duration-500"
      style={{
        backgroundColor: scrolled ? "rgba(245,243,238,0.95)" : "transparent",
        backdropFilter: scrolled ? "blur(24px)" : "none",
        borderBottom: scrolled ? `1px solid ${C.lineLight}` : "1px solid transparent",
      }}
    >
      <div className="mx-auto flex items-center justify-between" style={{ maxWidth: "1440px", padding: "0 clamp(24px, 4vw, 64px)", height: "80px" }}>
        <Link href="/" style={{
          fontFamily: sans,
          fontSize: "0.82rem",
          fontWeight: 700,
          letterSpacing: "0.18em",
          textTransform: "uppercase" as const,
          color: C.charcoal,
          textDecoration: "none",
        }}>
          Maître Ébéniste
        </Link>

        <div className="hidden md:flex items-center" style={{ gap: "clamp(1.5rem, 3vw, 3rem)" }}>
          {links.map((l) => (
            <a
              key={l.label}
              href={l.href}
              style={{
                fontFamily: sans,
                fontSize: "0.75rem",
                fontWeight: 500,
                letterSpacing: "0.12em",
                textTransform: "uppercase" as const,
                color: C.mid,
                textDecoration: "none",
                transition: "color 0.3s ease",
              }}
              onMouseEnter={(e) => (e.currentTarget.style.color = C.charcoal)}
              onMouseLeave={(e) => (e.currentTarget.style.color = C.mid)}
            >
              {l.label}
            </a>
          ))}
        </div>

        <button onClick={() => setMenuOpen(!menuOpen)} className="md:hidden p-2 -mr-2" aria-label="Menu">
          <div className="flex flex-col items-end" style={{ gap: "5px" }}>
            <span className="block h-[1.5px] transition-all duration-400" style={{
              backgroundColor: C.charcoal,
              width: menuOpen ? "20px" : "24px",
              transform: menuOpen ? "rotate(45deg) translateY(3.25px)" : "none",
            }} />
            <span className="block h-[1.5px] transition-all duration-400" style={{
              backgroundColor: C.charcoal,
              width: menuOpen ? "20px" : "18px",
              transform: menuOpen ? "rotate(-45deg) translateY(-3.25px)" : "none",
              opacity: menuOpen ? 1 : 0.7,
            }} />
          </div>
        </button>
      </div>

      <div
        className="md:hidden overflow-hidden transition-all duration-500"
        style={{
          maxHeight: menuOpen ? "400px" : "0",
          backgroundColor: C.ivory,
          borderTop: menuOpen ? `1px solid ${C.lineLight}` : "none",
        }}
      >
        <div className="flex flex-col py-8" style={{ padding: "2rem clamp(24px, 4vw, 64px)" }}>
          {links.map((l, i) => (
            <a
              key={l.label}
              href={l.href}
              onClick={() => setMenuOpen(false)}
              style={{
                fontFamily: sans,
                fontSize: "1rem",
                fontWeight: 500,
                letterSpacing: "0.08em",
                textTransform: "uppercase" as const,
                color: C.charcoal,
                textDecoration: "none",
                padding: "1rem 0",
                borderBottom: i < links.length - 1 ? `1px solid ${C.lineLight}` : "none",
              }}
            >
              {l.label}
            </a>
          ))}
        </div>
      </div>
    </nav>
  );
}

/* ══════════════════════════════════════════════════════════════
   HERO — Cinematic, title overlaid on image with white border
   ══════════════════════════════════════════════════════════════ */
function Hero() {
  const [offset, setOffset] = useState(0);
  useEffect(() => {
    const fn = () => setOffset(window.scrollY * 0.15);
    window.addEventListener("scroll", fn, { passive: true });
    return () => window.removeEventListener("scroll", fn);
  }, []);

  return (
    <section style={{ backgroundColor: C.ivory, paddingTop: "80px" }}>
      <div className="mx-auto" style={{ maxWidth: "1440px", padding: "clamp(12px, 3vw, 40px) clamp(16px, 4vw, 64px)" }}>
        <div className="relative overflow-hidden" style={{ backgroundColor: C.lineLight }}>
          <div className="overflow-hidden" style={{ height: "clamp(300px, 55vh, 720px)" }}>
            <img
              src={IMG.cuisineGrise}
              alt="Cuisine sur mesure — Maître Ébéniste"
              className="w-full h-full object-cover"
              style={{ transform: `translateY(${offset}px) scale(1.05)`, transition: "transform 0.1s linear" }}
            />
          </div>
          <div className="absolute inset-0" style={{
            background: "linear-gradient(180deg, rgba(28,28,28,0.08) 0%, rgba(28,28,28,0.25) 50%, rgba(28,28,28,0.4) 100%)",
          }} />
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <h1 style={{
              fontFamily: serif,
              fontSize: "clamp(2.4rem, 7vw, 5.5rem)",
              fontWeight: 300,
              fontStyle: "italic",
              color: "#FFFFFF",
              letterSpacing: "0.04em",
              lineHeight: 1,
              textShadow: "0 2px 60px rgba(0,0,0,0.2)",
            }}>
              Maître Ébéniste
            </h1>
            <p style={{
              fontFamily: sans,
              fontSize: "clamp(0.65rem, 1.2vw, 0.8rem)",
              fontWeight: 500,
              letterSpacing: "0.25em",
              textTransform: "uppercase" as const,
              color: "rgba(255,255,255,0.75)",
              marginTop: "clamp(12px, 2vw, 24px)",
            }}>
              Ébénisterie sur mesure — Montréal
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ══════════════════════════════════════════════════════════════
   SECTION DIVIDER — Thin line with label
   ══════════════════════════════════════════════════════════════ */
function SectionDivider({ label, id }: { label: string; id: string }) {
  return (
    <Reveal>
      <div id={id} className="mx-auto" style={{ maxWidth: "1440px", padding: "0 clamp(24px, 4vw, 64px)" }}>
        <div className="flex items-center" style={{ gap: "1.5rem", paddingBottom: "2.5rem" }}>
          <span style={{
            fontFamily: sans,
            fontSize: "0.7rem",
            fontWeight: 600,
            letterSpacing: "0.2em",
            textTransform: "uppercase" as const,
            color: C.light,
          }}>
            {label}
          </span>
          <div style={{ flex: 1, height: "1px", backgroundColor: C.line }} />
        </div>
      </div>
    </Reveal>
  );
}

/* ══════════════════════════════════════════════════════════════
   COMMERCIAL — 6 photos. Canva reference layout.
   Row 1: comm1 (large left ~65%) + comm2/comm3 stacked right (~35%)
   Row 2: comm4 + comm5 + comm6 — 3 PORTRAIT photos, equal width
   ══════════════════════════════════════════════════════════════ */
function SectionCommercial() {
  const allImages = [IMG.comm1, IMG.comm2, IMG.comm3, IMG.comm4, IMG.comm5, IMG.comm6];
  const [lightboxIdx, setLightboxIdx] = useState<number | null>(null);

  const gap = "clamp(8px, 1vw, 16px)";

  return (
    <section id="commercial" style={{ backgroundColor: C.ivory, paddingBottom: "clamp(4rem, 8vw, 7rem)" }}>
      <SectionDivider label="Commercial" id="commercial-top" />

      <div className="mx-auto" style={{ maxWidth: "1440px", padding: "0 clamp(24px, 4vw, 64px)" }}>

        {/* ── Row 1: comm1 (col-span-3, 4/3) + comm2/comm3 stacked (col-span-2, 16/9 each) ── */}
        <div className="grid grid-cols-1 md:grid-cols-5 mb-3 md:mb-4" style={{ gap }}>
          <Reveal className="md:col-span-3">
            <div onClick={() => setLightboxIdx(0)} className="cursor-pointer">
              <GalleryImage src={IMG.comm1} alt="Projet commercial" aspect="4/3" />
            </div>
          </Reveal>
          <div className="md:col-span-2 grid grid-rows-2" style={{ gap }}>
            <Reveal delay={120}>
              <div onClick={() => setLightboxIdx(1)} className="cursor-pointer">
                <GalleryImage src={IMG.comm2} alt="Projet commercial" aspect="16/9" mobileAspect="16/9" />
              </div>
            </Reveal>
            <Reveal delay={200}>
              <div onClick={() => setLightboxIdx(2)} className="cursor-pointer">
                <GalleryImage src={IMG.comm3} alt="Projet commercial" aspect="16/9" mobileAspect="16/9" />
              </div>
            </Reveal>
          </div>
        </div>

        {/* ── Row 2: comm4 + comm5 + comm6 — 3 PORTRAIT photos, same height ── */}
        <div className="grid grid-cols-1 sm:grid-cols-3 md:grid-cols-3" style={{ gap }}>
          <Reveal delay={100}>
            <div onClick={() => setLightboxIdx(3)} className="cursor-pointer">
              <GalleryImage src={IMG.comm4} alt="Projet commercial" aspect="3/4" mobileAspect="4/5" />
            </div>
          </Reveal>
          <Reveal delay={200}>
            <div onClick={() => setLightboxIdx(4)} className="cursor-pointer">
              <GalleryImage src={IMG.comm5} alt="Projet commercial" aspect="3/4" mobileAspect="4/5" />
            </div>
          </Reveal>
          <Reveal delay={300}>
            <div onClick={() => setLightboxIdx(5)} className="cursor-pointer">
              <GalleryImage src={IMG.comm6} alt="Projet commercial" aspect="3/4" mobileAspect="4/5" />
            </div>
          </Reveal>
        </div>
      </div>

      {lightboxIdx !== null && (
        <Lightbox images={allImages} index={lightboxIdx} onClose={() => setLightboxIdx(null)} onNav={setLightboxIdx} />
      )}
    </section>
  );
}

/* ══════════════════════════════════════════════════════════════
   RÉSIDENTIEL — EXACT Canva layout reproduction
   Row 1: res1Biblio (~40%) + res2Chevet (~30%) + res3MeubleTV (~30%) — same height
   Row 2: res4ArmoireBlanche + res5GardeRobe + res6ArmoireLuminaire — 3 equal portraits
   Row 3: cuisineBouleau + armoireBouleau1 + armoireBouleau2 — 3 equal
   Row 4: escalierEtageres + meubleTV — 2 equal (50/50)
   Row 5: res7898 + res8785 + res56F7 — 3 equal
   Row 6: biblio (~40%) + salon (~60%) — 2 cols
   Row 7: res3E55 (~60%) + res7FC2 (~40%) — 2 cols
   ══════════════════════════════════════════════════════════════ */
function SectionResidentiel() {
  const allImages = [
    IMG.res1Biblio, IMG.res2Chevet, IMG.res3MeubleTV,
    IMG.res4ArmoireBlanche, IMG.res5GardeRobe, IMG.res6ArmoireLuminaire,
    IMG.cuisineBouleau, IMG.armoireBouleau1, IMG.armoireBouleau2,
    IMG.escalierEtageres, IMG.meubleTV,
    IMG.res7898, IMG.res8785, IMG.res56F7,
    IMG.biblio, IMG.salon,
    IMG.res3E55, IMG.res7FC2,
  ];
  const [lightboxIdx, setLightboxIdx] = useState<number | null>(null);
  const open = useCallback((i: number) => setLightboxIdx(i), []);

  const gap = "clamp(8px, 1vw, 16px)";

  return (
    <section id="residentiel" style={{ backgroundColor: C.ivory, paddingBottom: "clamp(4rem, 8vw, 7rem)" }}>
      <SectionDivider label="Résidentiel" id="residentiel-top" />

      <div className="mx-auto" style={{ maxWidth: "1440px", padding: "0 clamp(24px, 4vw, 64px)" }}>

        {/* ── Row 1: Biblio bûches (landscape ~40%) + Chevet lampe (portrait ~30%) + Meuble TV livres (portrait ~30%) ── */}
        <div className="grid grid-cols-1 md:grid-cols-[4fr_3fr_3fr] mb-3 md:mb-4" style={{ gap }}>
          <Reveal>
            <div onClick={() => open(0)} className="cursor-pointer">
              <GalleryImage src={IMG.res1Biblio} alt="Bibliothèque avec bûches" aspect="3/2" mobileAspect="3/2" objectPosition="center" />
            </div>
          </Reveal>
          <Reveal delay={100}>
            <div onClick={() => open(1)} className="cursor-pointer">
              <GalleryImage src={IMG.res2Chevet} alt="Table de chevet" aspect="2/3" mobileAspect="3/4" />
            </div>
          </Reveal>
          <Reveal delay={200}>
            <div onClick={() => open(2)} className="cursor-pointer">
              <GalleryImage src={IMG.res3MeubleTV} alt="Meuble TV avec livres" aspect="2/3" mobileAspect="3/4" />
            </div>
          </Reveal>
        </div>

        {/* ── Row 2: 3 portraits égaux — Armoire blanche + Garde-robe miroir + Armoire luminaire ── */}
        <div className="grid grid-cols-1 sm:grid-cols-3 md:grid-cols-3 mb-3 md:mb-4" style={{ gap }}>
          <Reveal>
            <div onClick={() => open(3)} className="cursor-pointer">
              <GalleryImage src={IMG.res4ArmoireBlanche} alt="Armoire blanche" aspect="3/4" mobileAspect="4/5" />
            </div>
          </Reveal>
          <Reveal delay={100}>
            <div onClick={() => open(4)} className="cursor-pointer">
              <GalleryImage src={IMG.res5GardeRobe} alt="Garde-robe avec miroir" aspect="3/4" mobileAspect="4/5" />
            </div>
          </Reveal>
          <Reveal delay={200}>
            <div onClick={() => open(5)} className="cursor-pointer">
              <GalleryImage src={IMG.res6ArmoireLuminaire} alt="Armoire avec luminaire" aspect="3/4" mobileAspect="4/5" />
            </div>
          </Reveal>
        </div>

        {/* ── Row 3: 3 photos égales — Cuisine bouleau + Armoire bouleau x2 ── */}
        <div className="grid grid-cols-1 sm:grid-cols-3 md:grid-cols-3 mb-3 md:mb-4" style={{ gap }}>
          <Reveal>
            <div onClick={() => open(6)} className="cursor-pointer">
              <GalleryImage src={IMG.cuisineBouleau} alt="Cuisine bouleau" aspect="4/3" mobileAspect="4/3" />
            </div>
          </Reveal>
          <Reveal delay={100}>
            <div onClick={() => open(7)} className="cursor-pointer">
              <GalleryImage src={IMG.armoireBouleau1} alt="Armoire bouleau" aspect="4/3" mobileAspect="4/3" />
            </div>
          </Reveal>
          <Reveal delay={200}>
            <div onClick={() => open(8)} className="cursor-pointer">
              <GalleryImage src={IMG.armoireBouleau2} alt="Armoire bouleau" aspect="4/3" mobileAspect="4/3" />
            </div>
          </Reveal>
        </div>

        {/* ── Row 4: 2 photos 50/50 — Escalier étagères + Mur TV noir ── */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 mb-3 md:mb-4" style={{ gap }}>
          <Reveal>
            <div onClick={() => open(9)} className="cursor-pointer">
              <GalleryImage src={IMG.escalierEtageres} alt="Escalier et étagères éclairées" aspect="4/3" mobileAspect="4/3" />
            </div>
          </Reveal>
          <Reveal delay={100}>
            <div onClick={() => open(10)} className="cursor-pointer">
              <GalleryImage src={IMG.meubleTV} alt="Mur TV avec foyer" aspect="4/3" mobileAspect="4/3" />
            </div>
          </Reveal>
        </div>

        {/* ── Row 5: 3 photos égales — Meuble TV bois + Bureau iMac + Armoire chêne ── */}
        <div className="grid grid-cols-1 sm:grid-cols-3 md:grid-cols-3 mb-3 md:mb-4" style={{ gap }}>
          <Reveal>
            <div onClick={() => open(11)} className="cursor-pointer">
              <GalleryImage src={IMG.res7898} alt="Meuble TV bois" aspect="4/3" mobileAspect="4/3" />
            </div>
          </Reveal>
          <Reveal delay={100}>
            <div onClick={() => open(12)} className="cursor-pointer">
              <GalleryImage src={IMG.res8785} alt="Bureau avec iMac" aspect="4/3" mobileAspect="4/3" />
            </div>
          </Reveal>
          <Reveal delay={200}>
            <div onClick={() => open(13)} className="cursor-pointer">
              <GalleryImage src={IMG.res56F7} alt="Armoire chêne" aspect="4/3" mobileAspect="4/3" />
            </div>
          </Reveal>
        </div>

        {/* ── Row 6: 2 photos — Bibliothèque TV (~40%) + Crédence blanche (~60%) ── */}
        <div className="grid grid-cols-1 md:grid-cols-[2fr_3fr] mb-3 md:mb-4" style={{ gap }}>
          <Reveal>
            <div onClick={() => open(14)} className="cursor-pointer">
              <GalleryImage src={IMG.biblio} alt="Bibliothèque avec TV" aspect="4/3" mobileAspect="4/3" />
            </div>
          </Reveal>
          <Reveal delay={100}>
            <div onClick={() => open(15)} className="cursor-pointer">
              <GalleryImage src={IMG.salon} alt="Crédence blanche" aspect="4/3" mobileAspect="4/3" />
            </div>
          </Reveal>
        </div>

        {/* ── Row 7: 2 photos — Miroir moulures (~60%) + Entrée console (~40%) ── */}
        <div className="grid grid-cols-1 md:grid-cols-[3fr_2fr]" style={{ gap }}>
          <Reveal>
            <div onClick={() => open(16)} className="cursor-pointer">
              <GalleryImage src={IMG.res3E55} alt="Miroir avec moulures" aspect="4/3" mobileAspect="4/3" />
            </div>
          </Reveal>
          <Reveal delay={100}>
            <div onClick={() => open(17)} className="cursor-pointer">
              <GalleryImage src={IMG.res7FC2} alt="Entrée avec console" aspect="4/3" mobileAspect="4/3" />
            </div>
          </Reveal>
        </div>
      </div>

      {lightboxIdx !== null && (
        <Lightbox images={allImages} index={lightboxIdx} onClose={() => setLightboxIdx(null)} onNav={setLightboxIdx} />
      )}
    </section>
  );
}

/* ══════════════════════════════════════════════════════════════
   NOS FORCES — Gros chiffres, aligné gauche, accordion
   No section title. Editorial numbered list.
   ══════════════════════════════════════════════════════════════ */
const forces = [
  {
    num: "01",
    title: "Haut de gamme",
    text: "Le haut de gamme ne signifie pas hors de prix. Il signifie exigence constante.\n\nPeu importe la taille du projet, le niveau de précision reste le même. Même rigueur. Même qualité de finition. Aucun compromis.\n\nL'exigence ne varie jamais.",
  },
  {
    num: "02",
    title: "Travail de précision",
    text: "Un atelier entièrement équipé. Des outils adaptés. Des années d'expérience mises au service du détail.\n\nChaque pièce est fabriquée avec maîtrise, constance et exactitude. La prise de mesure est capitale pour obtenir le résultat souhaité.\n\nPas de demi-mesure.",
  },
  {
    num: "03",
    title: "Bien pensé",
    text: "Rien n'est laissé au hasard. Chaque détail est réfléchi. Chaque étape est maîtrisée.\n\nLe meuble est beau, fonctionnel et conçu pour durer. L'esthétique rencontre l'intelligence d'usage.\n\nVos idées prennent forme.",
  },
  {
    num: "04",
    title: "Style sur mesure",
    text: "Le projet part de vos inspirations, de vos besoins, de vos goûts. Aucune signature imposée.\n\nJe travaille également en collaboration avec des designers et architectes aux univers variés. Le style s'adapte au projet, jamais l'inverse.\n\nVotre vision devient réalité.",
  },
  {
    num: "05",
    title: "Sans intermédiaires",
    text: "Aucun grossiste. Aucune sous-traitance. Aucun vendeur.\n\nJe conçois, je fabrique et je livre directement.\n\n• Pour les particuliers : votre projet prend vie à travers vos inspirations, vos besoins et votre budget.\n• Pour les designers et architectes : vos idées et votre créativité sont concrétisées avec précision, en respectant votre mandat et votre vision.\n\nTout est coordonné et structuré.",
  },
];

function ForceItem({ item, isOpen, onToggle }: { item: typeof forces[0]; isOpen: boolean; onToggle: () => void }) {
  const contentRef = useRef<HTMLDivElement>(null);
  const [height, setHeight] = useState(0);

  useEffect(() => {
    if (contentRef.current) {
      setHeight(isOpen ? contentRef.current.scrollHeight : 0);
    }
  }, [isOpen]);

  return (
    <div
      onClick={onToggle}
      className="cursor-pointer group"
      style={{ borderBottom: `1px solid ${C.line}` }}
    >
      <div className="flex items-center py-6 md:py-10" style={{ gap: "clamp(1rem, 3vw, 3.5rem)" }}>
        <span style={{
          fontFamily: serif,
          fontSize: "clamp(2.5rem, 7vw, 6rem)",
          fontWeight: 300,
          fontStyle: "italic",
          color: C.lineLight,
          minWidth: "clamp(3rem, 9vw, 8rem)",
          transition: "color 0.5s ease",
          lineHeight: 1,
          flexShrink: 0,
        }} className="group-hover:!text-[#C8C3BB]">
          {item.num}
        </span>

        <h3 style={{
          fontFamily: sans,
          fontSize: "clamp(1.1rem, 2.8vw, 2rem)",
          fontWeight: 500,
          color: C.charcoal,
          letterSpacing: "-0.01em",
          flex: 1,
          transition: "letter-spacing 0.4s ease",
        }}>
          {item.title}
        </h3>

        <span style={{
          fontFamily: sans,
          fontSize: "1.6rem",
          fontWeight: 300,
          color: C.faint,
          transition: "transform 0.4s cubic-bezier(0.22, 1, 0.36, 1), color 0.4s ease",
          transform: isOpen ? "rotate(45deg)" : "none",
          lineHeight: 1,
          flexShrink: 0,
        }} className="group-hover:!text-[#7A756D]">
          +
        </span>
      </div>

      <div style={{
        height: `${height}px`,
        overflow: "hidden",
        transition: "height 0.5s cubic-bezier(0.22, 1, 0.36, 1)",
      }}>
        <div ref={contentRef} style={{
          paddingLeft: "clamp(4rem, 12vw, 11.5rem)",
          paddingBottom: "2rem",
          paddingRight: "clamp(1rem, 3vw, 3rem)",
        }}>
          <p style={{
            fontFamily: sans,
            fontSize: "1rem",
            fontWeight: 400,
            color: C.mid,
            lineHeight: 1.8,
            maxWidth: "560px",
            whiteSpace: "pre-line",
          }}>
            {item.text}
          </p>
        </div>
      </div>
    </div>
  );
}

function SectionForces() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <section style={{ backgroundColor: C.ivory, padding: "clamp(4rem, 8vw, 8rem) 0" }}>
      <div className="mx-auto" style={{ maxWidth: "1100px", padding: "0 clamp(24px, 4vw, 64px)" }}>
        <div style={{ borderTop: `1px solid ${C.line}` }}>
          {forces.map((f, i) => (
            <Reveal key={f.num} delay={i * 50}>
              <ForceItem
                item={f}
                isOpen={openIdx === i}
                onToggle={() => setOpenIdx(openIdx === i ? null : i)}
              />
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ══════════════════════════════════════════════════════════════
   CONTACT — Elegant CTA — Address: 36-999 rue du Collège
   ══════════════════════════════════════════════════════════════ */
function SectionContact() {
  return (
    <section id="contact" style={{ backgroundColor: C.ivory, padding: "clamp(3rem, 6vw, 5rem) 0 clamp(4rem, 8vw, 7rem)" }}>
      <div className="mx-auto" style={{ maxWidth: "900px", padding: "0 clamp(24px, 4vw, 64px)" }}>
        <Reveal>
          <p style={{
            fontFamily: sans,
            fontSize: "0.7rem",
            fontWeight: 600,
            letterSpacing: "0.2em",
            textTransform: "uppercase" as const,
            color: C.light,
            marginBottom: "clamp(1.5rem, 3vw, 2.5rem)",
          }}>
            Contact
          </p>
        </Reveal>

        <Reveal delay={100}>
          <h2 style={{
            fontFamily: serif,
            fontSize: "clamp(2.2rem, 5vw, 4rem)",
            fontWeight: 300,
            fontStyle: "italic",
            color: C.charcoal,
            lineHeight: 1.15,
            marginBottom: "clamp(1.5rem, 3vw, 2.5rem)",
          }}>
            Vous avez un projet<br />en tête?
          </h2>
        </Reveal>

        <Reveal delay={200}>
          <a
            href="tel:5148673492"
            className="inline-block group"
            style={{ textDecoration: "none", marginBottom: "clamp(2.5rem, 5vw, 4rem)" }}
          >
            <span style={{
              fontFamily: sans,
              fontSize: "clamp(1.2rem, 2.5vw, 1.8rem)",
              fontWeight: 600,
              color: C.charcoal,
              borderBottom: `2px solid ${C.charcoal}`,
              paddingBottom: "6px",
              transition: "border-color 0.3s ease, color 0.3s ease",
            }}>
              514-867-3492
            </span>
          </a>
        </Reveal>

        <Reveal delay={300}>
          <div className="grid grid-cols-1 sm:grid-cols-3" style={{ gap: "clamp(1.5rem, 3vw, 2.5rem)", borderTop: `1px solid ${C.line}`, paddingTop: "clamp(1.5rem, 3vw, 2.5rem)" }}>
            <div>
              <p style={{ fontFamily: sans, fontSize: "0.68rem", fontWeight: 600, letterSpacing: "0.15em", textTransform: "uppercase" as const, color: C.light, marginBottom: "10px" }}>
                Atelier
              </p>
              <p style={{ fontFamily: sans, fontSize: "0.92rem", fontWeight: 500, color: C.dark, lineHeight: 1.6 }}>
                36-999 rue du Collège<br />Montréal
              </p>
            </div>
            <div>
              <p style={{ fontFamily: sans, fontSize: "0.68rem", fontWeight: 600, letterSpacing: "0.15em", textTransform: "uppercase" as const, color: C.light, marginBottom: "10px" }}>
                Services
              </p>
              <p style={{ fontFamily: sans, fontSize: "0.92rem", fontWeight: 500, color: C.dark, lineHeight: 1.6 }}>
                Résidentiel & Commercial<br />Particuliers, architectes & designers
              </p>
            </div>
            <div>
              <p style={{ fontFamily: sans, fontSize: "0.68rem", fontWeight: 600, letterSpacing: "0.15em", textTransform: "uppercase" as const, color: C.light, marginBottom: "10px" }}>
                Note
              </p>
              <p style={{ fontFamily: sans, fontSize: "0.92rem", fontWeight: 500, color: C.dark, lineHeight: 1.6 }}>
                Tarifs préférentiels<br />pour les membres de l'UDA
              </p>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

/* ══════════════════════════════════════════════════════════════
   FOOTER — Minimal, refined
   ══════════════════════════════════════════════════════════════ */
function Footer() {
  return (
    <footer style={{ backgroundColor: C.ivory, borderTop: `1px solid ${C.lineLight}`, padding: "clamp(1.2rem, 2vw, 2rem) 0" }}>
      <div className="mx-auto flex flex-col sm:flex-row justify-between items-center" style={{ maxWidth: "1440px", padding: "0 clamp(24px, 4vw, 64px)", gap: "0.5rem" }}>
        <span style={{ fontFamily: sans, fontSize: "0.72rem", fontWeight: 600, letterSpacing: "0.15em", textTransform: "uppercase" as const, color: C.dark }}>
          Maître Ébéniste
        </span>
        <p style={{ fontFamily: sans, fontSize: "0.72rem", fontWeight: 400, color: C.light }}>
          © {new Date().getFullYear()} Tous droits réservés
        </p>
      </div>
    </footer>
  );
}

/* ══════════════════════════════════════════════════════════════
   HOME — Assembled
   Order: Hero → Commercial → Résidentiel → Forces → Contact → Footer
   ══════════════════════════════════════════════════════════════ */
export default function Home() {
  return (
    <div style={{ backgroundColor: C.ivory, minHeight: "100vh" }}>
      <Navbar />
      <Hero />
      <div id="projets" style={{ height: 0 }} />
      <SectionCommercial />
      <SectionResidentiel />
      <SectionForces />
      <SectionContact />
      <Footer />
    </div>
  );
}
